package data.impl;

public class EmployeeDaoImpl {

}
