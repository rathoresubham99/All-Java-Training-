package testPackage;

public class Employee {
private int empno; //read only (only getter)
private String ename; // read only (only getter)
private String dept; // read and write (getter and setter)
private float sal; // read and write (getter and setter)

Employee(int empno, String ename) {
this.empno=empno;
this.ename=ename;
}
public int empno()
{
	return (this.empno+100000)
}
public String ename()
{
	return this.ename;
}
public String dept()
{
	return this.dept;
}
public void dept(String dept)
{
	this.dept=dept;
}
public float sal()
{
	return this.sal;
}

}
