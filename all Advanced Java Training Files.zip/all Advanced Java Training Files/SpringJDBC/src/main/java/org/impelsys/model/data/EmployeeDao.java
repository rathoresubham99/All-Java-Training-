package org.impelsys.model.data;


import java.util.List;

import org.springframework.stereotype.Repository;

public interface EmployeeDao{
	

}
