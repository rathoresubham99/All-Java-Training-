//package org.impelsys.controller;
//
//import java.io.IOException;
//import java.io.PrintWriter;
//
//import javax.security.auth.message.callback.PrivateKeyCallback.Request;
//import javax.servlet.RequestDispatcher;
//import javax.servlet.ServletConfig;
//import javax.servlet.ServletException;
//import javax.servlet.http.Cookie;
//import javax.servlet.http.HttpServlet;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//import javax.servlet.http.HttpSession;
//
//import com.sun.org.apache.bcel.internal.generic.GotoInstruction;
//
//public class HelloWorldController extends HttpServlet {
//private String userName;
//private int hitCounter;
//
////called only the first time a request is received 
//public void init(ServletConfig config) throws ServletException
//{
//	System.out.println("Initializing the HelloWorldController");
//	hitCounter =0;
//	
//}
////public void service(HttpServletRequest req, HttpServletResponse res) throws IOException
////{
////	hitCounter++;
////	res.setContentType("text/html");
////	Cookie userCookie =  new Cookie("uname",userName); //always added as part of response
////
////	System.out.println("Handling Incoming Request...");
////	res.addCookie(userCookie);
////	PrintWriter out = res.getWriter();
////	
////	String str = req.getParameter("user");
////	out.println("<h2>");
////	out.println("Hello, Good morning..."+" "+str+" "+"you are"+" "+" visitor"+" "+hitCounter);
////	out.println("</h2>");
////	out.println("<form action='secondServlet'>");
////	out.println("<input type='submit' value='Go Inside'/>");
////	out.println("</form>"); out.flush();
////}
//public void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException
//{
//	HttpSession session = req.getSession();
//	session.setAttribute("userName", userName);
//	hitCounter++;
//	res.setContentType("text/html");
//	res.setHeader("Cache-Control", "no-store"); //fresh page fetch from server
//	res.setDateHeader("Expires", 0);  //Don't store pages...
//	userName= req.getParameter("user");
//	Cookie userCookie =  new Cookie("uname",userName); //always added as part of response
//  // userCookie.setMaxAge(0); 
//	System.out.println("Handling Incoming Request...");
//	res.addCookie(userCookie);
//	PrintWriter out = res.getWriter();
//	
//	out.println("<h2>");
//	out.println("Hello, Good morning..."+" "+userName+" "+"you are"+" "+" visitor"+" "+hitCounter);
//	out.println("</h2>");
////	out.println("<form action='secondServlet'>");
////	out.println("<input type='submit' value='Go Inside'/>");
////	out.println("</form>"); 
//	RequestDispatcher rDispatcher = req.getRequestDispatcher("/secondServlet");
//	rDispatcher.forward(req, res);
//}
//public void destroy()
//{
//	System.out.println("Doing the cleaning Activities...");
//}
//}
package org.impelsys.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/show")
public class HelloWorldController extends HttpServlet{
	private String userName;
	private int hitCounter;
	
	public void init(ServletConfig config) throws ServletException
	{
		System.out.println("initializing HelloWorldController");
		hitCounter=0;
	}
	
	//handles get method
	public void doGet(HttpServletRequest request,HttpServletResponse response) throws IOException,ServletException
	{
		System.out.println("Handling incoming request.... ");
		hitCounter++;
		PrintWriter pw = response.getWriter();
		//pw.println("Hello");
		

		//Set response content type
		//response.setContentType("text/html"); //MIME type
		PrintWriter pw1 = response.getWriter();
		pw1.println("<h2>");
		userName=request.getParameter("userName");
		pw1.println("hello ,Good Morning  "+ "u  have visited "+ hitCounter + "  times");
	}
		//handles post method
	public void doPost(HttpServletRequest request,HttpServletResponse response) throws IOException, ServletException
	{
		System.out.println("Handling Post method");
		response.setContentType("text/html");
		response.setHeader("Cache-Control","no-store");
		response.setDateHeader("Expires",0);
		RequestDispatcher reqDispatcher = request.getRequestDispatcher("secondServlet");
		reqDispatcher.include(request, response);
		//System.out.println("redirecting to second Serclet");
		//response.sendRedirect("www.google.com");
		
		PrintWriter pw = response.getWriter();
		userName=request.getParameter("userName");
		pw.println("Hello"+ userName);
		//save user name
		/*Cookie userCookie=new Cookie("uname", userName);
		userCookie.setMaxAge(5); //milliseconds
		response.addCookie(userCookie);*/
		
		
		HttpSession session=request.getSession();
		session.setAttribute("userName", userName);
		//System.out.println("redirecting to second Serclet");
		//response.sendRedirect("secondServlet");
		/*pw.println("<form action='POST'>");
		pw.println("<input type='submit' value='Go in'>");
		pw.println("</form>");*/
		//RequestDispatcher reqDispatcher = request.getRequestDispatcher("secondServlet");
		//reqDispatcher.forward(request, response);
		//reqDispatcher.include(request, response);

		
	}
	
	
		public void destroy()
		{
			//cleanup activities
			System.out.println("in Destroy" );
		}
		
	}