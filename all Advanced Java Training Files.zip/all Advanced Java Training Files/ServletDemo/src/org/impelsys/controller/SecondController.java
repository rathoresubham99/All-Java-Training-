//package org.impelsys.controller;
//
//import java.io.IOException;
//import java.io.PrintWriter;
//
//import javax.servlet.http.Cookie;
//import javax.servlet.http.HttpServlet;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//import javax.servlet.http.HttpSession;
//
//public class SecondController extends HttpServlet{
//	{
//		System.out.println("Initializing the secondController");
//
//	}
//	public void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException
//	
//	{
//		
//		HttpSession HttpSession = req.getSession();
//		PrintWriter out = res.getWriter();
////		Cookie cookie[] = req.getCookies();
//		String userName = (String) HttpSession.getAttribute("userName");
//		if(userName == null)
//		{
//			System.out.println("Invalid user");
//		}
////		for(Cookie c: cookie)
////		{
////			out.println("Hello "+userName+ " You are in 2nd page.");
////		}
//		else
//		out.println("Hello "+userName+ "I am in Second page...");
//	}
//}
package org.impelsys.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/secondServlet")
public class SecondController extends HttpServlet {
	
	public void init(ServletConfig config) throws ServletException
	{
		System.out.println("initializing SecondController");
	
	}
	
	//handles get method
	public void doPost(HttpServletRequest request,HttpServletResponse response) throws IOException
	{
		PrintWriter pw=response.getWriter();
		//Cookie cookie[]=request.getCookies();
		/*String userName=null;
		if(cookie!=null){
			userName=cookie[0].getValue();
		}*/
		
		
		HttpSession session=request.getSession(false);
		
		String userName=(String)session.getAttribute("userName");
		if(userName==null)
			pw.println("invalid user");
			else
			pw.println("Hello " + userName + "  you r in 2nd page...");
	}
}