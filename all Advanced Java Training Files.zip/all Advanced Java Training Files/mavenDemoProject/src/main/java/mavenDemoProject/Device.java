package mavenDemoProject;

public class Device {
private String type;
private String modelNum;
public String getType() {
	return type;
}
public void setType(String type) {
	this.type = type;
}
public String getModelNum() {
	return modelNum;
}
public void setModelNum(String modelNum) {
	this.modelNum = modelNum;
}

}
