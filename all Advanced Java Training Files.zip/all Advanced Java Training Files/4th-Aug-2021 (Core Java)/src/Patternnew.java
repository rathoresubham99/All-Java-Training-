import java.util.*;
public class Patternnew {

	public static void main(String[] args) {
	Scanner scanner= new Scanner(System.in);
	System.out.println("Enter the First Number");

	}

}
