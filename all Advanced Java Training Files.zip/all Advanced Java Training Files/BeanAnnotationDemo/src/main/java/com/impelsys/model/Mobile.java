package com.impelsys.model;

public interface Mobile {

	public void config();
}
