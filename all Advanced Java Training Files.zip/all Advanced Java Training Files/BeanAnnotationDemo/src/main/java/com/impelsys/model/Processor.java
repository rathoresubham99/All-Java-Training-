package com.impelsys.model;

public interface Processor {
public void config();
}
