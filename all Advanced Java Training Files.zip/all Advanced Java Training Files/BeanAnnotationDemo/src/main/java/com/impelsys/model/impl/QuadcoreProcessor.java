package com.impelsys.model.impl;

import org.springframework.stereotype.Component;

import com.impelsys.model.Processor;
@Component
public class QuadcoreProcessor implements Processor {

	public void config() {
		// TODO Auto-generated method stub
		System.out.println("This is a Quadcore Processor...");

	}

}
